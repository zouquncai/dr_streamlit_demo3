# This is in the top level so that you can add dr_streamlit via a git submodule
import os, sys; sys.path.append(os.path.dirname(os.path.realpath(__file__)))
